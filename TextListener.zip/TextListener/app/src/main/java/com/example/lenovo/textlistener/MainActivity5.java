package com.example.lenovo.textlistener;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity5 extends AppCompatActivity {
Button b1,b2,b3,b4,b5,b6,b7,b8;

EditText et1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        b1=(Button)findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        b3=(Button)findViewById(R.id.button3);
        b4=(Button)findViewById(R.id.button4);
        b5=(Button)findViewById(R.id.button5);
        b6=(Button)findViewById(R.id.button6);
        b7=(Button)findViewById(R.id.button7);
        b8=(Button)findViewById(R.id.button8);
        et1=(EditText)findViewById(R.id.editText);

        et1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {



               /* String str=et1.getText().toString();
                String[] sep=str.split(",");
                for(int i=0;i<sep.length;i++){
                    if(sep[i].equals("red"))
                    {
                        b1.setBackgroundColor(Color.RED);
                    }
                    else if(sep[i].equals("blue"))
                    {
                        b2.setBackgroundColor(Color.BLUE);
                    }
                        else if(sep[i].equals("green"))
                        {
                            b3.setBackgroundColor(Color.GREEN);
                        }
                        else if(sep[i].equals("black"))
                        {
                            b4.setBackgroundColor(Color.BLACK);
                        }
                        else if(sep[i].equals("yellow"))
                        {
                            b5.setBackgroundColor(Color.YELLOW);
                        }
                        else if(sep[i].equals("gray"))
                        {
                            b6.setBackgroundColor(Color.GRAY);
                        }
                        else if(sep[i].equals("magenta"))
                        {
                            b7.setBackgroundColor(Color.MAGENTA);
                        }
                        else if(sep[i].equals("cyan"))
                        {
                            b8.setBackgroundColor(Color.CYAN);
                        }
                    flag=true;
                }*/
            }




            @Override
            public void afterTextChanged(Editable s) {

                String[] str=et1.getText().toString().split(",");

                boolean r=false,b=false,g=false,bk=false,y=false,gy=false,m=false,c=false;



                // tt.setText(str[]);
                //String str2 = str.toString();
                for(int i=0;i<str.length;i++)
                {
                    if((str[i].matches("red|green|blue|black|yellow|magenta|gray|cyan")))
                    {
                        if(str[i].contentEquals("red"))
                        {
                            b1.setBackgroundColor(Color.RED);
                            r=true;
                        }


                        if(str[i].contentEquals("green"))
                        {
                            b3.setBackgroundColor(Color.GREEN);
                            g=true;
                        }


                        if(str[i].contentEquals("blue"))
                        {
                            b2.setBackgroundColor(Color.BLUE);
                            b=true;
                        }
                        if(str[i].contentEquals("black"))
                        {
                            b4.setBackgroundColor(Color.BLACK);
                            bk=true;
                        }
                        if(str[i].contentEquals("yellow"))
                        {
                            b5.setBackgroundColor(Color.YELLOW);
                            y=true;
                        }
                        if(str[i].contentEquals("gray"))
                        {
                            b6.setBackgroundColor(Color.GRAY);
                            gy=true;
                        }
                        if(str[i].contentEquals("magenta"))
                        {
                            b7.setBackgroundColor(Color.MAGENTA);
                            m=true;
                        }
                        if(str[i].contentEquals("cyan"))
                        {
                            b8.setBackgroundColor(Color.CYAN);
                            c=true;
                        }

                        if(r==true)
                        {
                            b1.setBackgroundColor(Color.RED);
                        }
                        else
                        {

                            b1.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(b==true)
                        {
                            b2.setBackgroundColor(Color.BLUE);
                        }
                        else
                        {

                            b2.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(g==true)
                        {
                            b3.setBackgroundColor(Color.GREEN);
                        }
                        else{

                            b3.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(bk==true)
                        {
                            b4.setBackgroundColor(Color.BLACK);
                        }
                        else{

                            b4.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(y==true)
                        {
                            b5.setBackgroundColor(Color.YELLOW);
                        }
                        else{

                            b5.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(gy==true)
                        {
                            b6.setBackgroundColor(Color.GRAY);
                        }
                        else{

                            b6.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(m==true)
                        {
                            b7.setBackgroundColor(Color.MAGENTA);
                        }
                        else{

                            b7.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(c==true)
                        {
                            b8.setBackgroundColor(Color.CYAN);
                        }
                        else{

                            b8.setBackgroundResource(android.R.drawable.btn_default);
                        }

                    }
                   else{
                        if(r==false)
                        {
                            b1.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(g==false)
                        {
                            b3.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(b==false)
                        {
                            b2.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(bk==false)
                        {
                            b4.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(y==false)
                        {
                            b5.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(gy==false)
                        {
                            b6.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(m==false)
                        {
                            b7.setBackgroundResource(android.R.drawable.btn_default);
                        }
                        if(c==false)
                        {
                            b8.setBackgroundResource(android.R.drawable.btn_default);
                        }
                    }
                }


            }
        });




    }
}
